#Made By Samuel Desmon
#Visit Github : IlhamGods

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import square
from scipy.integrate import quad

x = np.arange(-np.pi, np.pi, 0.001)

y = square(x)

n = 50
An = []
Bn = []

for i in range(1, n + 1):
    fc = lambda x, i=i: square(x) * np.cos(i * x)
    fs = lambda x, i=i: square(x) * np.sin(i * x)

    An.append(quad(fc, -np.pi, np.pi)[0] * (1.0 / np.pi))
    Bn.append(quad(fs, -np.pi, np.pi)[0] * (1.0 / np.pi))

result = np.zeros_like(x)

for i in range(n):
    if i == 0:
        result += An[i] / 2
    else:
        result += An[i] * np.cos(i * x) + Bn[i] * np.sin(i * x)

plt.plot(x, result, 'g')
plt.plot(x, y, 'r--')
plt.title("Fourier Series for Square Wave")
plt.show()
